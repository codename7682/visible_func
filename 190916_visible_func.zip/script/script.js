$(document).ready(function(){
    
    $("#hidebtn").click(function(){
        $("#box").slideUp(1000,"swing",function(){
//            alert("숨기기가 끝났습니다.");
        });
    });
    
    $("#showbtn").click(function(){
        $("#box").slideDown(1000,"swing");
    });
    // #hidebtn이 눌리면
        // #box를 숨기자.
    // #showbtn이 눌리면
        // #box를 보이자.
    
    // #togglebtn이 눌리면
        // #box를 숨기거나/보여준다.
//    $("#togglebtn").click(function(){
//        $("#box").toggle();
//    });
    
//    $("#togglebtn").click(function(){
//        var dp = $("#box").css("display");
//        if(dp == "none"){
//            $("#box").show();
//        }else{
//            $("#box").hide();
//        }
//    });
    // #togglebtn이 눌렸을때
        // #box의 스타일중에 "display"의 값을 알아내서
        // 만약 그 값이 "none"이라면 (현재 박스가 안보이니 보여줄차례)       
            // #box를 보여주기
        // 그렇지 않다면 (현재 박스가 보이고있으니 숨기겠다)
            // #box를 숨겨주기
    
    var stat = true;
    $("#togglebtn").click(function(){
        if(stat){
            $("#box").fadeOut();
            stat = false;
        }else{
            $("#box").fadeIn();
            stat = true;
        }
    });
    
    // 변수 stat에 true을 넣어둔다.
    //      stat이 true 이라는 뜻은 박스가 보이고 있다.
    //      stat이 false이라는 뜻은 박스가 안보이고 있다.
    // #togglebtn이 눌렸을때
        // 만약 stat이 true라면 (박스가 보이고 있으니 숨기기)
            // #box를 숨겨주기.
            // stat에 false를 넣기
        // 그게 아니라면 (박스가 안보이고 있으니 보이기)
            // #box를 보여주기.
            // stat에 true를 넣기
    
    
    var stat2 = 1;
    $("#semibtn").click(function(){
        if(stat2 == 1){
            $("#box").fadeTo(400,0.7);
            stat2 = 2;
        }else if(stat2 == 2){
            $("#box").fadeTo(400,0.3);
            stat2 = 3;
        }else if(stat2 == 3){
            $("#box").fadeTo(400,0);
            stat2 = 4;
        }else{
            $("#box").fadeTo(400,1);
            stat2 = 1;
        }
    });
    // 변수 stat2에 1을 넣어둠.
         // stat2가 1이란 뜻은 투명도가 1이라는 뜻
         // stat2가 2이란 뜻은 투명도가 0.7이라는 뜻
         // stat2가 3이란 뜻은 투명도가 0.3이라는 뜻
         // stat2가 4이란 뜻은 투명도가 0이라는 뜻
    // #semibtn이 눌리면
        // 만약 stat2가 1이라면
            // #box의 투명도를 0.7로 만들자
            // stat2의 값을 2
        // 그게 아니고 만약 stat2가 2이라면
            // #box의 투명도를 0.3으로 만들자
            // stat2의 값을 3
        // 그게 아니고 만약 stat2가 3이라면
            // #box의 투명도를 0으로 만들자
            // stat2의 값을 4
        // 그게 아니라면
            // #box의 투명도를 1로 만들자
            // stat2의 값을 1
        
    
   
    
    // fn(대상:string, 재생시간:ms, 가속도:string)
    function slideLeft(who,dur, acc){
        if(dur == undefined){
            dur = 400;
        }
        $(who).css({
            overflow:"hidden",
            whiteSpace:"nowrap"
        });
        $(who).animate({width:0},dur,acc,function(){
            $(who).css("overflow","auto");
            $(who).hide();
        });
    }
    
    $("#sleft").click(function(){
        slideLeft("#box",400,"swing");
    });
    
    $("#big").click(function(){
        $("#box").animate({
            width:"500px",
            height:"500px",
            fontSize: "+=30px"
        },1000,"linear");
    });
    
    $("#small").click(function(){
        $("#box").animate({
            width:"300px",
            height:"300px",
            fontSize: "-=30px"
        },1000,"linear");
    });
    // #big이 눌리면
        // #box의 1초에 걸쳐서 가로길이를 500px로 변하게 한다.
    
    // #small이 눌리면
        // #box의 1초에 걸쳐서 가로길이를 300px로 변하게 한다.
    
    
    $("#toright").click(function(){
        $("#box").animate({
            marginLeft:"200px"
        },{
            duration:1000,
            easing:"linear"
        }); 
        $("#box").animate({marginTop:"100px"},1000,"linear");
    });
    $("#toleft").click(function(){
        $("#box").animate({marginTop:"0px"},1000,"linear");
        $("#box").animate({marginLeft:"0px"},1000,"linear");
    });
    
    // #toright를 누르면
        // #box가 오른쪽으로 200px 움직인다.
        // (#box의 스타일 중 "margin-left"의 값을 200px로)
    // #toleft를 누르면
        // #box가 왼쪽으로 200px 움직인다.
        // (#box의 스타일 중 "margin-left"의 값을 0px로)
    
    function rot(){
        $("#box").animate({
            dummy: "+=360"
        },{
            duration: 2000,
            easing: "linear",
            step: function(now,fx){
                var a = parseInt(now);
                $(this).css("transform","rotate("+a+"deg)");             
            },
            complete: function(){
                rot();
            }
        });
    }
    
    $("#tored").click(function(){
        rot();
    });
    
//#tored가 눌리면
    // #box를 움직여 줄껀데
    // transform:rotate(?deg)를 이용해야 되는데 못함
    // 그리고 저 ?에 0부터 360까지의 숫자를 넣어야함
    // 그래서 멍텅구리 애니메이션을 만들었음
    // dummy(바지사장)라는 말도 안되는 스타일이 0부터 360까지 커짐
    // 이때 걸리는 시간은 2000ms
    // 이때 움직임의 가속도는 "linear"(등속도운동)
    // 그런데 그 애니메이션 매 순간순간마다 해줄 내용
        // 현재 dummy의 값 => now
        // 그 now라는 값을 이용해서
        // transform: "rotate(" +now+ "deg)"
    // 마침내 애니메이션이 끝나면
    // 다음번 실행을 위해서 미리 되감기 해둠
        // dummy의 값을 0으로 되돌리기
        // tranform의 값을 rotate(0deg)로 되돌리기
    
    // #pause버튼이 눌리면
        // #box를 멈춰라.
    $("#pause").click(function(){
        $("#box").stop();
    });
    
    
    
    
    
    
    
});










